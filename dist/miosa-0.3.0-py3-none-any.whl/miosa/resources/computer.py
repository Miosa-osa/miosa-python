"""Bound Computer object — all actions scoped to a single computer ID."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional, Union

from ..types import (
    ActionResponse,
    DirEntry,
    ExecResult,
    FileStat,
)
from ..types import (
    Computer as ComputerModel,
)
from .agent import AgentResource, AsyncAgentResource
from .checkpoints import AsyncCheckpoints, Checkpoints
from .custom_domains import AsyncCustomDomains, CustomDomains
from .desktop import AsyncDesktopMixin, DesktopMixin
from .events import AsyncEvents, Events
from .exec import AsyncExecResource, ExecResource
from .files import AsyncFilesResource, FilesResource
from .network_policy import AsyncNetworkPolicy, NetworkPolicy
from .services import AsyncServices, Services

if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


# ───────────────────────────────────────────────────────────────────────────
# ScopedFs — file ops rooted at a fixed working directory
# ───────────────────────────────────────────────────────────────────────────

def _resolve(working_dir: str, path: str) -> str:
    if path.startswith("/"):
        return path
    prefix = working_dir if working_dir != "/" else ""
    prefix = prefix.rstrip("/") if working_dir != "/" else working_dir
    joined = f"{prefix}/{path}" if prefix else f"/{path}"
    while "/./" in joined:
        joined = joined.replace("/./", "/")
    while "//" in joined:
        joined = joined.replace("//", "/")
    return joined


class ScopedFs:
    """Thin wrapper around :class:`FilesResource` rooted at a working dir.

    Obtained via :meth:`Computer.fs`::

        fs = computer.fs("/workspace")
        fs.write_file("main.py", "print('hi')")
        source = fs.read_file("main.py")
    """

    def __init__(self, files: FilesResource, working_dir: str) -> None:
        self._files = files
        self._working_dir = (
            working_dir if working_dir == "/" else working_dir.rstrip("/")
        )

    def _r(self, path: str) -> str:
        return _resolve(self._working_dir, path)

    def write_file(self, path: str, content: Union[str, bytes]) -> None:
        self._files.write_file(self._r(path), content)

    def read_file(self, path: str) -> str:
        return self._files.read_file(self._r(path))

    def readdir(self, path: str) -> List[DirEntry]:
        return self._files.readdir(self._r(path))

    def stat(self, path: str) -> FileStat:
        return self._files.stat(self._r(path))

    def mkdir(
        self,
        path: str,
        *,
        recursive: bool = True,
        mode: Optional[Union[int, str]] = None,
    ) -> None:
        self._files.mkdir(self._r(path), recursive=recursive, mode=mode)

    def rename(self, source: str, dest: str) -> None:
        self._files.rename(self._r(source), self._r(dest))

    def copy(self, source: str, dest: str, *, recursive: bool = False) -> None:
        self._files.copy(self._r(source), self._r(dest), recursive=recursive)

    def chmod(self, path: str, mode: Union[int, str]) -> None:
        self._files.chmod(self._r(path), mode)


class AsyncScopedFs:
    """Async counterpart to :class:`ScopedFs`."""

    def __init__(self, files: AsyncFilesResource, working_dir: str) -> None:
        self._files = files
        self._working_dir = (
            working_dir if working_dir == "/" else working_dir.rstrip("/")
        )

    def _r(self, path: str) -> str:
        return _resolve(self._working_dir, path)

    async def write_file(self, path: str, content: Union[str, bytes]) -> None:
        await self._files.write_file(self._r(path), content)

    async def read_file(self, path: str) -> str:
        return await self._files.read_file(self._r(path))

    async def readdir(self, path: str) -> List[DirEntry]:
        return await self._files.readdir(self._r(path))

    async def stat(self, path: str) -> FileStat:
        return await self._files.stat(self._r(path))

    async def mkdir(
        self,
        path: str,
        *,
        recursive: bool = True,
        mode: Optional[Union[int, str]] = None,
    ) -> None:
        await self._files.mkdir(self._r(path), recursive=recursive, mode=mode)

    async def rename(self, source: str, dest: str) -> None:
        await self._files.rename(self._r(source), self._r(dest))

    async def copy(
        self, source: str, dest: str, *, recursive: bool = False
    ) -> None:
        await self._files.copy(self._r(source), self._r(dest), recursive=recursive)

    async def chmod(self, path: str, mode: Union[int, str]) -> None:
        await self._files.chmod(self._r(path), mode)


# ───────────────────────────────────────────────────────────────────────────
# Computer — sync
# ───────────────────────────────────────────────────────────────────────────

class Computer(DesktopMixin):
    """A single MIOSA computer with all action methods.

    Returned by ``ComputersResource.create()`` / ``.get()`` etc.
    Provides desktop control, exec, files, agent, checkpoints, services,
    domains, network policy, and events sub-resources.
    """

    def __init__(self, transport: SyncTransport, data: ComputerModel) -> None:
        self._transport = transport
        self._data = data
        self._computer_id = data.id

        # Sub-resources
        self.files = FilesResource(transport, self._computer_id)
        self.agent = AgentResource(transport, self._computer_id)
        self._exec = ExecResource(transport, self._computer_id)
        self.checkpoints = Checkpoints(transport, self._computer_id)
        self.services = Services(transport, self._computer_id)
        self.domains = CustomDomains(transport, self._computer_id)
        self.network_policy = NetworkPolicy(transport, self._computer_id)
        self.events = Events(transport, self._computer_id)

    # -- properties exposing model data --

    @property
    def id(self) -> str:
        return self._data.id

    @property
    def name(self) -> str:
        return self._data.name

    @property
    def status(self) -> str:
        return self._data.status.value

    @property
    def slug(self) -> str:
        """URL-safe slug — falls back to the raw id when unset."""
        return self._data.slug or self._data.id

    @property
    def data(self) -> ComputerModel:
        """The underlying Pydantic model."""
        return self._data

    @property
    def exec(self) -> ExecResource:
        """Command execution helper (``bash`` / ``python`` / ``spawn``)."""
        return self._exec

    def __repr__(self) -> str:
        return f"Computer(id={self.id!r}, name={self.name!r}, status={self.status!r})"

    # -- preview URLs -------------------------------------------------------

    def preview_url(self, port: int, path: str = "/") -> str:
        """Public HTTPS URL that forwards to ``port`` inside the VM.

        Example::

            computer.bash("python -m http.server 3000 &")
            url = computer.preview_url(3000)
            # => "https://3000-<slug>.sandbox.miosa.ai/"
        """
        p = path if path.startswith("/") else f"/{path}"
        return f"https://{port}-{self.slug}.sandbox.miosa.ai{p}"

    @property
    def public_url(self) -> str:
        """Root preview URL — whatever is served on the default app port."""
        return f"https://{self.slug}.sandbox.miosa.ai"

    # -- lifecycle ----------------------------------------------------------

    def start(self) -> ActionResponse:
        """Start the computer."""
        data = self._transport.request(
            "POST", f"/computers/{self._computer_id}/start"
        )
        return ActionResponse.model_validate(data)

    def stop(self) -> ActionResponse:
        """Stop the computer."""
        data = self._transport.request(
            "POST", f"/computers/{self._computer_id}/stop"
        )
        return ActionResponse.model_validate(data)

    def restart(self) -> ActionResponse:
        """Restart the computer."""
        data = self._transport.request(
            "POST", f"/computers/{self._computer_id}/restart"
        )
        return ActionResponse.model_validate(data)

    def destroy(self) -> ActionResponse:
        """Permanently destroy the computer."""
        data = self._transport.request(
            "DELETE", f"/computers/{self._computer_id}"
        )
        return ActionResponse.model_validate(data)

    def refresh(self) -> Computer:
        """Re-fetch this computer's data from the API."""
        data = self._transport.request(
            "GET", f"/computers/{self._computer_id}"
        )
        self._data = ComputerModel.model_validate(data)
        return self

    # -- exec shortcuts -----------------------------------------------------

    def bash(self, command: str, *, timeout: Optional[int] = None) -> ExecResult:
        """Execute a bash command on the computer."""
        return self._exec.bash(command, timeout=timeout)

    def run(self, command: str, *, timeout: Optional[int] = None) -> ExecResult:
        """Execute a shell command.

        Alias for :meth:`bash`, matching the simple sandbox SDK pattern used by
        Hugging Face and Modal-style examples.
        """
        return self.bash(command, timeout=timeout)

    def python(self, code: str, *, timeout: Optional[int] = None) -> ExecResult:
        """Execute Python code on the computer."""
        return self._exec.python(code, timeout=timeout)

    # -- file shortcuts -----------------------------------------------------

    def write_file(self, path: str, content: Union[str, bytes]) -> None:
        """Write bytes or UTF-8 text to a file inside the computer."""
        self.files.write_file(path, content)

    def read_file(self, path: str) -> str:
        """Read a file from the computer and decode it as UTF-8."""
        return self.files.read_file(path)

    # -- scoped filesystem --------------------------------------------------

    def fs(self, working_dir: str) -> ScopedFs:
        """Return a :class:`ScopedFs` rooted at ``working_dir``.

        Example::

            fs = computer.fs("/workspace")
            fs.write_file("main.py", "print(1)")
            src = fs.read_file("main.py")
        """
        return ScopedFs(self.files, working_dir)


# ───────────────────────────────────────────────────────────────────────────
# AsyncComputer
# ───────────────────────────────────────────────────────────────────────────

class AsyncComputer(AsyncDesktopMixin):
    """Async version of the bound Computer object."""

    def __init__(self, transport: AsyncTransport, data: ComputerModel) -> None:
        self._transport = transport
        self._data = data
        self._computer_id = data.id

        self.files = AsyncFilesResource(transport, self._computer_id)
        self.agent = AsyncAgentResource(transport, self._computer_id)
        self._exec = AsyncExecResource(transport, self._computer_id)
        self.checkpoints = AsyncCheckpoints(transport, self._computer_id)
        self.services = AsyncServices(transport, self._computer_id)
        self.domains = AsyncCustomDomains(transport, self._computer_id)
        self.network_policy = AsyncNetworkPolicy(transport, self._computer_id)
        self.events = AsyncEvents(transport, self._computer_id)

    @property
    def id(self) -> str:
        return self._data.id

    @property
    def name(self) -> str:
        return self._data.name

    @property
    def status(self) -> str:
        return self._data.status.value

    @property
    def slug(self) -> str:
        return self._data.slug or self._data.id

    @property
    def data(self) -> ComputerModel:
        return self._data

    @property
    def exec(self) -> AsyncExecResource:
        return self._exec

    def __repr__(self) -> str:
        return f"AsyncComputer(id={self.id!r}, name={self.name!r}, status={self.status!r})"

    def preview_url(self, port: int, path: str = "/") -> str:
        p = path if path.startswith("/") else f"/{path}"
        return f"https://{port}-{self.slug}.sandbox.miosa.ai{p}"

    @property
    def public_url(self) -> str:
        return f"https://{self.slug}.sandbox.miosa.ai"

    async def start(self) -> ActionResponse:
        data = await self._transport.request(
            "POST", f"/computers/{self._computer_id}/start"
        )
        return ActionResponse.model_validate(data)

    async def stop(self) -> ActionResponse:
        data = await self._transport.request(
            "POST", f"/computers/{self._computer_id}/stop"
        )
        return ActionResponse.model_validate(data)

    async def restart(self) -> ActionResponse:
        data = await self._transport.request(
            "POST", f"/computers/{self._computer_id}/restart"
        )
        return ActionResponse.model_validate(data)

    async def destroy(self) -> ActionResponse:
        data = await self._transport.request(
            "DELETE", f"/computers/{self._computer_id}"
        )
        return ActionResponse.model_validate(data)

    async def refresh(self) -> AsyncComputer:
        data = await self._transport.request(
            "GET", f"/computers/{self._computer_id}"
        )
        self._data = ComputerModel.model_validate(data)
        return self

    async def bash(self, command: str, *, timeout: Optional[int] = None) -> ExecResult:
        return await self._exec.bash(command, timeout=timeout)

    async def run(self, command: str, *, timeout: Optional[int] = None) -> ExecResult:
        return await self.bash(command, timeout=timeout)

    async def python(self, code: str, *, timeout: Optional[int] = None) -> ExecResult:
        return await self._exec.python(code, timeout=timeout)

    async def write_file(self, path: str, content: Union[str, bytes]) -> None:
        await self.files.write_file(path, content)

    async def read_file(self, path: str) -> str:
        return await self.files.read_file(path)

    def fs(self, working_dir: str) -> AsyncScopedFs:
        return AsyncScopedFs(self.files, working_dir)
