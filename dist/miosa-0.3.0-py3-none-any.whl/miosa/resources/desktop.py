"""Desktop control mixin — screenshot, click, type, key, scroll, drag, etc."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from ..types import (
    ActionResponse,
    ClickRequest,
    CursorPosition,
    DoubleClickRequest,
    DragRequest,
    KeyRequest,
    LaunchRequest,
    MouseButton,
    ScrollDirection,
    ScrollRequest,
    TypeRequest,
    WaitRequest,
    WindowFocusRequest,
    WindowInfo,
)

if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class DesktopMixin:
    """Synchronous desktop control methods.

    Expects ``self._transport`` (``SyncTransport``) and
    ``self._computer_id`` (``str``) to be set by the owning class.
    """

    _transport: SyncTransport
    _computer_id: str

    def _desktop_path(self, action: str) -> str:
        return f"/computers/{self._computer_id}/desktop/{action}"

    def screenshot(self) -> bytes:
        """Capture a PNG screenshot of the desktop."""
        resp = self._transport.request(
            "GET", self._desktop_path("screenshot"), raw_response=True
        )
        if resp.status_code >= 400:
            from ..errors import raise_for_status, _extract_request_id
            from .._http import _parse_body
            body = _parse_body(resp)
            raise_for_status(resp.status_code, body, _extract_request_id(resp))
        return resp.content

    def click(
        self,
        x: int,
        y: int,
        button: str = "left",
    ) -> ActionResponse:
        body = ClickRequest(x=x, y=y, button=MouseButton(button))
        data = self._transport.request(
            "POST", self._desktop_path("click"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    def double_click(self, x: int, y: int) -> ActionResponse:
        body = DoubleClickRequest(x=x, y=y)
        data = self._transport.request(
            "POST", self._desktop_path("double-click"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    def type(self, text: str, *, delay: Optional[int] = None) -> ActionResponse:
        body = TypeRequest(text=text, delay=delay)
        data = self._transport.request(
            "POST",
            self._desktop_path("type"),
            json_body=body.model_dump(exclude_none=True),
        )
        return ActionResponse.model_validate(data)

    def key(self, key: str) -> ActionResponse:
        body = KeyRequest(key=key)
        data = self._transport.request(
            "POST", self._desktop_path("key"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    def scroll(
        self,
        direction: str = "down",
        clicks: int = 3,
        *,
        x: Optional[int] = None,
        y: Optional[int] = None,
    ) -> ActionResponse:
        body = ScrollRequest(
            direction=ScrollDirection(direction), clicks=clicks, x=x, y=y
        )
        data = self._transport.request(
            "POST",
            self._desktop_path("scroll"),
            json_body=body.model_dump(exclude_none=True),
        )
        return ActionResponse.model_validate(data)

    def drag(
        self, from_x: int, from_y: int, to_x: int, to_y: int
    ) -> ActionResponse:
        body = DragRequest(from_x=from_x, from_y=from_y, to_x=to_x, to_y=to_y)
        data = self._transport.request(
            "POST", self._desktop_path("drag"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    def wait(self, seconds: float) -> ActionResponse:
        body = WaitRequest(seconds=seconds)
        data = self._transport.request(
            "POST", self._desktop_path("wait"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    def cursor(self) -> CursorPosition:
        data = self._transport.request("GET", self._desktop_path("cursor"))
        return CursorPosition.model_validate(data)

    def windows(self) -> List[WindowInfo]:
        data = self._transport.request("GET", self._desktop_path("windows"))
        if isinstance(data, dict) and "data" in data:
            return [WindowInfo.model_validate(w) for w in data["data"]]
        if isinstance(data, list):
            return [WindowInfo.model_validate(w) for w in data]
        return []

    def focus_window(self, window_id: str) -> ActionResponse:
        body = WindowFocusRequest(window_id=window_id)
        data = self._transport.request(
            "POST",
            self._desktop_path("window/focus"),
            json_body=body.model_dump(),
        )
        return ActionResponse.model_validate(data)

    def launch(self, app_name: str) -> ActionResponse:
        body = LaunchRequest(app_name=app_name)
        data = self._transport.request(
            "POST", self._desktop_path("launch"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)


class AsyncDesktopMixin:
    """Asynchronous desktop control methods."""

    _transport: AsyncTransport
    _computer_id: str

    def _desktop_path(self, action: str) -> str:
        return f"/computers/{self._computer_id}/desktop/{action}"

    async def screenshot(self) -> bytes:
        resp = await self._transport.request(
            "GET", self._desktop_path("screenshot"), raw_response=True
        )
        if resp.status_code >= 400:
            from ..errors import raise_for_status, _extract_request_id
            from .._http import _parse_body
            body = _parse_body(resp)
            raise_for_status(resp.status_code, body, _extract_request_id(resp))
        return resp.content

    async def click(
        self,
        x: int,
        y: int,
        button: str = "left",
    ) -> ActionResponse:
        body = ClickRequest(x=x, y=y, button=MouseButton(button))
        data = await self._transport.request(
            "POST", self._desktop_path("click"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    async def double_click(self, x: int, y: int) -> ActionResponse:
        body = DoubleClickRequest(x=x, y=y)
        data = await self._transport.request(
            "POST", self._desktop_path("double-click"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    async def type(self, text: str, *, delay: Optional[int] = None) -> ActionResponse:
        body = TypeRequest(text=text, delay=delay)
        data = await self._transport.request(
            "POST",
            self._desktop_path("type"),
            json_body=body.model_dump(exclude_none=True),
        )
        return ActionResponse.model_validate(data)

    async def key(self, key: str) -> ActionResponse:
        body = KeyRequest(key=key)
        data = await self._transport.request(
            "POST", self._desktop_path("key"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    async def scroll(
        self,
        direction: str = "down",
        clicks: int = 3,
        *,
        x: Optional[int] = None,
        y: Optional[int] = None,
    ) -> ActionResponse:
        body = ScrollRequest(
            direction=ScrollDirection(direction), clicks=clicks, x=x, y=y
        )
        data = await self._transport.request(
            "POST",
            self._desktop_path("scroll"),
            json_body=body.model_dump(exclude_none=True),
        )
        return ActionResponse.model_validate(data)

    async def drag(
        self, from_x: int, from_y: int, to_x: int, to_y: int
    ) -> ActionResponse:
        body = DragRequest(from_x=from_x, from_y=from_y, to_x=to_x, to_y=to_y)
        data = await self._transport.request(
            "POST", self._desktop_path("drag"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    async def wait(self, seconds: float) -> ActionResponse:
        body = WaitRequest(seconds=seconds)
        data = await self._transport.request(
            "POST", self._desktop_path("wait"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)

    async def cursor(self) -> CursorPosition:
        data = await self._transport.request("GET", self._desktop_path("cursor"))
        return CursorPosition.model_validate(data)

    async def windows(self) -> List[WindowInfo]:
        data = await self._transport.request("GET", self._desktop_path("windows"))
        if isinstance(data, dict) and "data" in data:
            return [WindowInfo.model_validate(w) for w in data["data"]]
        if isinstance(data, list):
            return [WindowInfo.model_validate(w) for w in data]
        return []

    async def focus_window(self, window_id: str) -> ActionResponse:
        body = WindowFocusRequest(window_id=window_id)
        data = await self._transport.request(
            "POST",
            self._desktop_path("window/focus"),
            json_body=body.model_dump(),
        )
        return ActionResponse.model_validate(data)

    async def launch(self, app_name: str) -> ActionResponse:
        body = LaunchRequest(app_name=app_name)
        data = await self._transport.request(
            "POST", self._desktop_path("launch"), json_body=body.model_dump()
        )
        return ActionResponse.model_validate(data)
