"""Tests for the MIOSA Python SDK client, resources, and error handling."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from miosa import Miosa, AsyncMiosa
from miosa.errors import (
    AuthenticationError,
    InsufficientCreditsError,
    MiosaError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)

from .conftest import API_KEY, BASE_URL, COMPUTER_JSON


# ---------------------------------------------------------------------------
# Client initialization
# ---------------------------------------------------------------------------

class TestClientInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="No API key"):
            Miosa()

    def test_accepts_api_key_kwarg(self):
        client = Miosa(api_key="msk_u_test")
        assert client._transport._api_key == "msk_u_test"
        client.close()

    def test_reads_env_var(self, monkeypatch):
        monkeypatch.setenv("MIOSA_API_KEY", "msk_u_env")
        client = Miosa()
        assert client._transport._api_key == "msk_u_env"
        client.close()

    def test_custom_base_url(self):
        client = Miosa(api_key="msk_u_test", base_url="https://custom.api/v1")
        assert client._transport._base_url == "https://custom.api/v1"
        client.close()

    def test_context_manager(self):
        with Miosa(api_key="msk_u_test") as client:
            assert client is not None

    def test_repr(self):
        client = Miosa(api_key="msk_u_test", base_url="https://api.miosa.ai/api/v1")
        assert "api.miosa.ai" in repr(client)
        client.close()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:
    def test_401_raises_auth_error(self, mock_api, client):
        mock_api.get("/computers").respond(
            401, json={"error": "Invalid API key"}
        )
        with pytest.raises(AuthenticationError):
            client.computers.list()

    def test_402_raises_insufficient_credits(self, mock_api, client):
        mock_api.post("/computers").respond(
            402, json={"message": "Insufficient credits"}
        )
        with pytest.raises(InsufficientCreditsError):
            client.computers.create(name="test")

    def test_404_raises_not_found(self, mock_api, client):
        mock_api.get("/computers/nonexistent").respond(
            404, json={"error": "Not found"}
        )
        with pytest.raises(NotFoundError):
            client.computers.get("nonexistent")

    def test_422_raises_validation_error(self, mock_api, client):
        mock_api.post("/computers").respond(
            422, json={"errors": ["name is required"]}
        )
        with pytest.raises(ValidationError):
            client.computers.create(name="")

    def test_429_raises_rate_limit_error(self, mock_api, client):
        mock_api.get("/computers").respond(
            429,
            json={"message": "Rate limited", "retry_after": 5.0},
            headers={"retry-after": "5"},
        )
        with pytest.raises(RateLimitError) as exc_info:
            client.computers.list()
        assert exc_info.value.retry_after == 5.0

    def test_500_raises_server_error(self, mock_api, client):
        mock_api.get("/computers").respond(
            500, json={"error": "Internal server error"}
        )
        with pytest.raises(ServerError):
            client.computers.list()


# ---------------------------------------------------------------------------
# Computers resource
# ---------------------------------------------------------------------------

class TestComputers:
    def test_create(self, mock_api, client):
        mock_api.post("/computers").respond(200, json=COMPUTER_JSON)
        computer = client.computers.create(name="test-agent", size="small")
        assert computer.id == "comp_abc123"
        assert computer.name == "test-agent"
        assert computer.status == "running"

    def test_list(self, mock_api, client):
        mock_api.get("/computers").respond(
            200, json={"data": [COMPUTER_JSON]}
        )
        computers = client.computers.list()
        assert len(computers) == 1
        assert computers[0].id == "comp_abc123"

    def test_get(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        computer = client.computers.get("comp_abc123")
        assert computer.id == "comp_abc123"

    def test_update(self, mock_api, client):
        updated = {**COMPUTER_JSON, "name": "renamed"}
        mock_api.patch("/computers/comp_abc123").respond(200, json=updated)
        computer = client.computers.update("comp_abc123", name="renamed")
        assert computer.name == "renamed"

    def test_delete(self, mock_api, client):
        mock_api.delete("/computers/comp_abc123").respond(
            200, json={"success": True}
        )
        client.computers.delete("comp_abc123")


# ---------------------------------------------------------------------------
# Sandboxes helper
# ---------------------------------------------------------------------------

class TestSandboxes:
    def test_create_defaults_to_sandbox_template(self, mock_api, client):
        sandbox_json = {
            **COMPUTER_JSON,
            "name": "sandbox-test",
            "template_type": "miosa-sandbox",
        }
        mock_api.post("/computers").respond(200, json=sandbox_json)

        sandbox = client.sandboxes.create(name="sandbox-test")

        assert sandbox.name == "sandbox-test"
        assert sandbox.data.template_type == "miosa-sandbox"

    def test_create_accepts_image_alias(self, mock_api, client):
        sandbox_json = {
            **COMPUTER_JSON,
            "name": "sandbox-test",
            "template_type": "debian-12-sandbox-v8",
        }
        route = mock_api.post("/computers").respond(200, json=sandbox_json)

        sandbox = client.sandboxes.create(
            name="sandbox-test",
            image="debian-12-sandbox-v8",
        )

        assert sandbox.data.template_type == "debian-12-sandbox-v8"
        assert route.calls.last.request.content
        assert b"debian-12-sandbox-v8" in route.calls.last.request.content

    def test_create_generates_name(self, mock_api, client):
        sandbox_json = {
            **COMPUTER_JSON,
            "name": "sandbox-generated",
            "template_type": "miosa-sandbox",
        }
        route = mock_api.post("/computers").respond(200, json=sandbox_json)

        client.sandboxes.create()

        payload = json.loads(route.calls.last.request.content)
        assert payload["name"].startswith("sandbox-")
        assert payload["template_type"] == "miosa-sandbox"

    def test_image_and_template_type_are_mutually_exclusive(self, client):
        with pytest.raises(TypeError, match="either `image` or `template_type`"):
            client.sandboxes.create(
                image="debian-12-sandbox-v8",
                template_type="miosa-sandbox-dev",
            )


# ---------------------------------------------------------------------------
# Computer bound object
# ---------------------------------------------------------------------------

class TestComputerActions:
    @pytest.fixture
    def computer(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        return client.computers.get("comp_abc123")

    def test_start(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/start").respond(
            200, json={"success": True, "message": "started"}
        )
        result = computer.start()
        assert result.success is True

    def test_stop(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/stop").respond(
            200, json={"success": True}
        )
        result = computer.stop()
        assert result.success is True

    def test_restart(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/restart").respond(
            200, json={"success": True}
        )
        result = computer.restart()
        assert result.success is True

    def test_destroy(self, mock_api, computer):
        mock_api.delete("/computers/comp_abc123").respond(
            200, json={"success": True}
        )
        result = computer.destroy()
        assert result.success is True

    def test_refresh(self, mock_api, computer):
        updated = {**COMPUTER_JSON, "status": "stopped"}
        mock_api.get("/computers/comp_abc123").respond(200, json=updated)
        computer.refresh()
        assert computer.status == "stopped"

    def test_repr(self, computer):
        r = repr(computer)
        assert "comp_abc123" in r
        assert "test-agent" in r


# ---------------------------------------------------------------------------
# Desktop control
# ---------------------------------------------------------------------------

class TestDesktop:
    @pytest.fixture
    def computer(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        return client.computers.get("comp_abc123")

    def test_screenshot(self, mock_api, computer):
        png_bytes = b"\x89PNG\r\n\x1a\nfakeimage"
        mock_api.get("/computers/comp_abc123/desktop/screenshot").respond(
            200,
            content=png_bytes,
            headers={"content-type": "image/png"},
        )
        result = computer.screenshot()
        assert result == png_bytes

    def test_click(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/click").respond(
            200, json={"success": True}
        )
        result = computer.click(100, 200)
        assert result.success is True

    def test_double_click(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/double-click").respond(
            200, json={"success": True}
        )
        result = computer.double_click(100, 200)
        assert result.success is True

    def test_type(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/type").respond(
            200, json={"success": True}
        )
        result = computer.type("hello world")
        assert result.success is True

    def test_key(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/key").respond(
            200, json={"success": True}
        )
        result = computer.key("Enter")
        assert result.success is True

    def test_scroll(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/scroll").respond(
            200, json={"success": True}
        )
        result = computer.scroll("down", 3)
        assert result.success is True

    def test_drag(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/drag").respond(
            200, json={"success": True}
        )
        result = computer.drag(10, 10, 200, 200)
        assert result.success is True

    def test_wait(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/wait").respond(
            200, json={"success": True}
        )
        result = computer.wait(5)
        assert result.success is True

    def test_cursor(self, mock_api, computer):
        mock_api.get("/computers/comp_abc123/desktop/cursor").respond(
            200, json={"x": 512, "y": 384}
        )
        pos = computer.cursor()
        assert pos.x == 512
        assert pos.y == 384

    def test_windows(self, mock_api, computer):
        mock_api.get("/computers/comp_abc123/desktop/windows").respond(
            200,
            json={"data": [{"id": "w1", "title": "Terminal", "focused": True}]},
        )
        wins = computer.windows()
        assert len(wins) == 1
        assert wins[0].title == "Terminal"

    def test_focus_window(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/window/focus").respond(
            200, json={"success": True}
        )
        result = computer.focus_window("w1")
        assert result.success is True

    def test_launch(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/desktop/launch").respond(
            200, json={"success": True}
        )
        result = computer.launch("firefox")
        assert result.success is True


# ---------------------------------------------------------------------------
# Exec
# ---------------------------------------------------------------------------

class TestExec:
    @pytest.fixture
    def computer(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        return client.computers.get("comp_abc123")

    def test_bash(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/exec").respond(
            200, json={"output": "total 8\ndrwxr-xr-x", "success": True}
        )
        result = computer.bash("ls -la")
        assert result.success is True
        assert "total 8" in result.output

    def test_python(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/exec/python").respond(
            200, json={"output": "4\n", "success": True}
        )
        result = computer.python("print(2+2)")
        assert result.success is True
        assert "4" in result.output

    def test_run_alias(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/exec").respond(
            200, json={"output": "2\n", "success": True}
        )
        result = computer.run("python3 -c 'print(1+1)'")
        assert result.success is True
        assert result.output == "2\n"


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------

class TestFiles:
    @pytest.fixture
    def computer(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        return client.computers.get("comp_abc123")

    def test_list_files(self, mock_api, computer):
        mock_api.get("/computers/comp_abc123/files").respond(
            200,
            json={
                "data": [
                    {"name": "readme.txt", "path": "/home/user/readme.txt", "is_dir": False, "size": 42}
                ]
            },
        )
        files = computer.files.list("/home/user")
        assert len(files) == 1
        assert files[0].name == "readme.txt"

    def test_download(self, mock_api, computer):
        content = b"file content here"
        mock_api.get("/computers/comp_abc123/files/download").respond(
            200,
            content=content,
            headers={"content-type": "application/octet-stream"},
        )
        result = computer.files.download("/home/user/readme.txt")
        assert result == content

    def test_upload(self, mock_api, computer, tmp_path):
        local_file = tmp_path / "test.txt"
        local_file.write_text("hello")
        mock_api.post("/computers/comp_abc123/files/upload").respond(
            200, json={"success": True}
        )
        result = computer.files.upload(str(local_file), "/home/user/test.txt")
        assert result.success is True

    def test_direct_write_and_read_file_aliases(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/files/write").respond(
            200, json={"success": True}
        )
        computer.write_file("/workspace/foo.txt", "hello")

        mock_api.get("/computers/comp_abc123/files/download").respond(
            200,
            content=b"hello",
            headers={"content-type": "application/octet-stream"},
        )
        assert computer.read_file("/workspace/foo.txt") == "hello"

    def test_delete_file(self, mock_api, computer):
        mock_api.delete("/computers/comp_abc123/files").respond(
            200, json={"success": True}
        )
        result = computer.files.delete("/home/user/readme.txt")
        assert result.success is True

    def test_export(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/files/export").respond(
            200, json={"success": True}
        )
        result = computer.files.export("/home/user/readme.txt")
        assert result.success is True


# ---------------------------------------------------------------------------
# Agent / CUA sessions
# ---------------------------------------------------------------------------

SESSION_JSON = {
    "id": "sess_xyz789",
    "computer_id": "comp_abc123",
    "goal": "Open Firefox",
    "status": "running",
    "model_id": "nemotron-3-super",
    "max_turns": 50,
    "turns_used": 3,
    "result": None,
    "error": None,
    "created_at": "2026-04-01T00:00:00Z",
    "updated_at": "2026-04-01T00:00:00Z",
}


class TestAgent:
    @pytest.fixture
    def computer(self, mock_api, client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        return client.computers.get("comp_abc123")

    def test_run(self, mock_api, computer):
        mock_api.post("/computers/comp_abc123/cua/sessions").respond(
            200, json=SESSION_JSON
        )
        session = computer.agent.run(goal="Open Firefox", model_id="nemotron-3-super")
        assert session.id == "sess_xyz789"
        assert session.goal == "Open Firefox"
        assert session.status.value == "running"

    def test_list_sessions(self, mock_api, computer):
        mock_api.get("/computers/comp_abc123/cua/sessions").respond(
            200, json={"data": [SESSION_JSON]}
        )
        sessions = computer.agent.list()
        assert len(sessions) == 1

    def test_get_session(self, mock_api, computer):
        mock_api.get("/computers/comp_abc123/cua/sessions/sess_xyz789").respond(
            200, json=SESSION_JSON
        )
        session = computer.agent.get("sess_xyz789")
        assert session.id == "sess_xyz789"

    def test_cancel_session(self, mock_api, computer):
        cancelled = {**SESSION_JSON, "status": "cancelled"}
        mock_api.delete("/computers/comp_abc123/cua/sessions/sess_xyz789").respond(
            200, json=cancelled
        )
        session = computer.agent.cancel("sess_xyz789")
        assert session.status.value == "cancelled"


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------

class TestCredits:
    def test_get_balance(self, mock_api, client):
        mock_api.get("/credits/balance").respond(
            200, json={"balance": 4200.0, "plan": "pro"}
        )
        balance = client.get_balance()
        assert balance.balance == 4200.0
        assert balance.plan == "pro"

    def test_get_transactions(self, mock_api, client):
        mock_api.get("/credits/transactions").respond(
            200,
            json={
                "data": [
                    {
                        "id": "txn_1",
                        "amount": -10.0,
                        "type": "compute",
                        "description": "Small VM 1h",
                    }
                ]
            },
        )
        txns = client.get_transactions()
        assert len(txns.data) == 1
        assert txns.data[0].amount == -10.0

    def test_get_usage(self, mock_api, client):
        mock_api.get("/credits/usage").respond(
            200, json={"compute": 100.0, "ai": 50.0, "total": 150.0}
        )
        usage = client.get_usage()
        assert usage.total == 150.0


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class TestAsyncClient:
    @pytest.mark.asyncio
    async def test_create_computer(self, mock_api, async_client):
        mock_api.post("/computers").respond(200, json=COMPUTER_JSON)
        computer = await async_client.computers.create(name="test-agent")
        assert computer.id == "comp_abc123"
        await async_client.close()

    @pytest.mark.asyncio
    async def test_click(self, mock_api, async_client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        mock_api.post("/computers/comp_abc123/desktop/click").respond(
            200, json={"success": True}
        )
        computer = await async_client.computers.get("comp_abc123")
        result = await computer.click(100, 200)
        assert result.success is True
        await async_client.close()

    @pytest.mark.asyncio
    async def test_bash(self, mock_api, async_client):
        mock_api.get("/computers/comp_abc123").respond(200, json=COMPUTER_JSON)
        mock_api.post("/computers/comp_abc123/exec").respond(
            200, json={"output": "hello", "success": True}
        )
        computer = await async_client.computers.get("comp_abc123")
        result = await computer.bash("echo hello")
        assert result.output == "hello"
        await async_client.close()

    @pytest.mark.asyncio
    async def test_get_balance(self, mock_api, async_client):
        mock_api.get("/credits/balance").respond(
            200, json={"balance": 1000.0, "plan": "starter"}
        )
        balance = await async_client.get_balance()
        assert balance.balance == 1000.0
        await async_client.close()
