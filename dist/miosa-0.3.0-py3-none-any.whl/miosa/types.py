"""Pydantic v2 models for MIOSA API request and response types."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ComputerSize(str, Enum):
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    XL = "xl"


class ComputerStatus(str, Enum):
    CREATING = "creating"
    PROVISIONING = "provisioning"
    STARTING = "starting"
    # `running` is the documented state; `active` is the legacy value the
    # server still emits for a running VM. Accept both — clients should
    # treat them as equivalent.
    RUNNING = "running"
    ACTIVE = "active"
    PAUSED = "paused"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"
    DESTROYED = "destroyed"


class ComputerVisibility(str, Enum):
    """Controls who can access the computer's HTTP preview URL."""

    PUBLIC = "public"
    TENANT = "tenant"
    KEY = "key"


class SnapshotStatus(str, Enum):
    CREATING = "creating"
    UPLOADING = "uploading"
    READY = "ready"
    RESTORING = "restoring"
    FAILED = "failed"
    DELETED = "deleted"


class ServiceStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


class CustomDomainStatus(str, Enum):
    PENDING = "pending"
    VERIFIED = "verified"
    ACTIVE = "active"
    FAILED = "failed"
    REMOVED = "removed"


class NetworkPolicyEffect(str, Enum):
    ALLOW = "allow"
    DENY = "deny"


class NetworkPolicyProtocol(str, Enum):
    TCP = "tcp"
    UDP = "udp"
    ANY = "any"


class MouseButton(str, Enum):
    LEFT = "left"
    RIGHT = "right"
    MIDDLE = "middle"


class ScrollDirection(str, Enum):
    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"


class AgentSessionStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


# ---------------------------------------------------------------------------
# Computers
# ---------------------------------------------------------------------------

class Computer(BaseModel):
    """A MIOSA computer (cloud VM for AI agents)."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    slug: Optional[str] = None
    status: ComputerStatus
    template_type: Optional[str] = Field(None, alias="template_type")
    size: Optional[ComputerSize] = None
    ip_address: Optional[str] = Field(None, alias="ip_address")
    visibility: Optional[ComputerVisibility] = None
    sandbox_url: Optional[str] = Field(None, alias="sandbox_url")
    desktop_url: Optional[str] = Field(None, alias="desktop_url")
    workspace_id: Optional[str] = Field(None, alias="workspace_id")
    tenant_id: Optional[str] = Field(None, alias="tenant_id")
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")
    metadata: Optional[Dict[str, Any]] = None


class ComputerCreate(BaseModel):
    """Payload for creating a computer."""

    name: str
    template_type: str = "miosa-desktop"
    size: ComputerSize = ComputerSize.SMALL
    visibility: Optional[ComputerVisibility] = None
    metadata: Optional[Dict[str, Any]] = None


class ComputerUpdate(BaseModel):
    """Payload for updating a computer."""

    name: Optional[str] = None
    visibility: Optional[ComputerVisibility] = None
    metadata: Optional[Dict[str, Any]] = None


class ComputerList(BaseModel):
    """Paginated list of computers."""

    data: List[Computer]
    total: Optional[int] = None


# ---------------------------------------------------------------------------
# Desktop
# ---------------------------------------------------------------------------

class ClickRequest(BaseModel):
    x: int
    y: int
    button: MouseButton = MouseButton.LEFT


class DoubleClickRequest(BaseModel):
    x: int
    y: int


class TypeRequest(BaseModel):
    text: str
    delay: Optional[int] = None


class KeyRequest(BaseModel):
    key: str


class ScrollRequest(BaseModel):
    direction: ScrollDirection
    clicks: int = 3
    x: Optional[int] = None
    y: Optional[int] = None


class DragRequest(BaseModel):
    from_x: int
    from_y: int
    to_x: int
    to_y: int


class WaitRequest(BaseModel):
    seconds: float


class LaunchRequest(BaseModel):
    app_name: str


class WindowFocusRequest(BaseModel):
    window_id: str


class CursorPosition(BaseModel):
    x: int
    y: int


class WindowInfo(BaseModel):
    id: str
    title: Optional[str] = None
    app: Optional[str] = None
    x: Optional[int] = None
    y: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    focused: Optional[bool] = None


# ---------------------------------------------------------------------------
# Exec
# ---------------------------------------------------------------------------

class ExecRequest(BaseModel):
    command: str
    timeout: Optional[int] = None


class PythonExecRequest(BaseModel):
    code: str
    timeout: Optional[int] = None


class ExecResult(BaseModel):
    output: str
    success: bool


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------

class FileInfo(BaseModel):
    name: str
    path: str
    size: Optional[int] = None
    is_dir: bool = Field(False, alias="is_dir")
    modified_at: Optional[datetime] = Field(None, alias="modified_at")

    model_config = ConfigDict(populate_by_name=True)


class FileList(BaseModel):
    data: List[FileInfo]


# ---------------------------------------------------------------------------
# Agent / CUA Sessions
# ---------------------------------------------------------------------------

class AgentSessionCreate(BaseModel):
    goal: str
    model_id: Optional[str] = None
    max_turns: Optional[int] = None


class AgentSession(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    computer_id: Optional[str] = Field(None, alias="computer_id")
    goal: str
    status: AgentSessionStatus
    model_id: Optional[str] = Field(None, alias="model_id")
    max_turns: Optional[int] = Field(None, alias="max_turns")
    turns_used: Optional[int] = Field(None, alias="turns_used")
    result: Optional[str] = None
    error: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


class AgentSessionList(BaseModel):
    data: List[AgentSession]


class AgentEvent(BaseModel):
    """A single SSE event from an agent session stream."""

    type: str
    data: Any = None
    id: Optional[str] = None


# ---------------------------------------------------------------------------
# Credits / Billing
# ---------------------------------------------------------------------------

class CreditBalance(BaseModel):
    # The platform API returns `balance_credits` (integer) + lifetime totals.
    # Accept both `balance_credits` and the legacy `balance` shape so older
    # test fixtures keep working.
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    balance: int = Field(alias="balance_credits")
    tenant_id: Optional[str] = None
    lifetime_earned: Optional[int] = None
    lifetime_spent: Optional[int] = None
    credit_expiry_at: Optional[datetime] = Field(None, alias="credit_expiry_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")
    # Legacy optional fields kept for backwards compatibility.
    currency: Optional[str] = None
    plan: Optional[str] = None
    expires_at: Optional[datetime] = None


class CreditTransaction(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    amount: float
    type: str
    description: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="created_at")


class CreditTransactionList(BaseModel):
    data: List[CreditTransaction]


class CreditUsage(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    compute: Optional[float] = None
    ai: Optional[float] = None
    storage: Optional[float] = None
    total: Optional[float] = None
    period_start: Optional[datetime] = Field(None, alias="period_start")
    period_end: Optional[datetime] = Field(None, alias="period_end")


# ---------------------------------------------------------------------------
# Generic
# ---------------------------------------------------------------------------

class ActionResponse(BaseModel):
    """Generic action response (start, stop, restart, etc.)."""

    success: bool = True
    message: Optional[str] = None
    status: Optional[str] = None


# ---------------------------------------------------------------------------
# Filesystem (stdlib-parity)
# ---------------------------------------------------------------------------

class FileStat(BaseModel):
    """Stat info for a file — mirrors the TS ``FileStat`` shape."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    path: str
    size: int
    mode: int
    is_dir: bool = Field(alias="is_dir")
    is_symlink: bool = Field(alias="is_symlink")
    symlink_target: Optional[str] = Field(None, alias="symlink_target")
    modified_at: Optional[datetime] = Field(None, alias="modified_at")


class DirEntry(BaseModel):
    """A single entry in a ``readdir`` listing."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    name: str
    is_dir: bool = Field(alias="is_dir")
    is_symlink: bool = Field(alias="is_symlink")
    size: int = 0
    modified_at: Optional[datetime] = Field(None, alias="modified_at")


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------

class WorkspaceData(BaseModel):
    """A tenant workspace — a logical grouping of computers."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    id: str
    name: str
    slug: Optional[str] = None
    tenant_id: Optional[str] = Field(None, alias="tenant_id")
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


class WorkspaceCreate(BaseModel):
    name: str
    slug: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class WorkspaceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Checkpoints / Snapshots
# ---------------------------------------------------------------------------

class SnapshotData(BaseModel):
    """A Firecracker microVM checkpoint."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    id: str
    computer_id: str = Field(alias="computer_id")
    tenant_id: Optional[str] = Field(None, alias="tenant_id")
    comment: Optional[str] = None
    status: SnapshotStatus
    state_size_bytes: Optional[int] = Field(None, alias="state_size_bytes")
    memory_size_bytes: Optional[int] = Field(None, alias="memory_size_bytes")
    rootfs_size_bytes: Optional[int] = Field(None, alias="rootfs_size_bytes")
    compressed_size_bytes: Optional[int] = Field(None, alias="compressed_size_bytes")
    s3_bucket: Optional[str] = Field(None, alias="s3_bucket")
    s3_prefix: Optional[str] = Field(None, alias="s3_prefix")
    parent_snapshot_id: Optional[str] = Field(None, alias="parent_snapshot_id")
    error: Optional[str] = None
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


class SnapshotProgressEvent(BaseModel):
    """SSE progress event emitted during checkpoint create/restore."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    type: str = "snapshot_progress"
    snapshot_id: str = Field(alias="snapshot_id")
    status: str
    step: Optional[str] = None
    progress: Optional[float] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Services
# ---------------------------------------------------------------------------

class ServiceData(BaseModel):
    """A long-running background service managed by the platform."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    id: str
    computer_id: str = Field(alias="computer_id")
    name: str
    command: str
    status: ServiceStatus
    working_dir: Optional[str] = Field(None, alias="working_dir")
    env: Optional[Dict[str, str]] = None
    restart_policy: Optional[str] = Field(None, alias="restart_policy")
    port: Optional[int] = None
    pid: Optional[int] = None
    exit_code: Optional[int] = Field(None, alias="exit_code")
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


class ServiceLogEvent(BaseModel):
    """A single log line emitted by a service."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    stream: str  # "stdout" | "stderr"
    line: str
    timestamp: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Custom Domains
# ---------------------------------------------------------------------------

class CustomDomainData(BaseModel):
    """A custom FQDN mapped to a computer."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    id: str
    computer_id: str = Field(alias="computer_id")
    tenant_id: Optional[str] = Field(None, alias="tenant_id")
    fqdn: str
    status: CustomDomainStatus
    verification_target: Optional[str] = Field(None, alias="verification_target")
    instructions: Optional[str] = None
    verified_at: Optional[datetime] = Field(None, alias="verified_at")
    tls_issued_at: Optional[datetime] = Field(None, alias="tls_issued_at")
    created_at: Optional[datetime] = Field(None, alias="created_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


# ---------------------------------------------------------------------------
# Network Policy
# ---------------------------------------------------------------------------

class NetworkPolicyRule(BaseModel):
    """A single egress rule."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    effect: NetworkPolicyEffect
    destination: str
    ports: Optional[str] = None
    protocol: Optional[NetworkPolicyProtocol] = None


class NetworkPolicyData(BaseModel):
    """The current egress policy applied to a computer."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    computer_id: Optional[str] = Field(None, alias="computer_id")
    tenant_id: Optional[str] = Field(None, alias="tenant_id")
    rules: List[NetworkPolicyRule] = Field(default_factory=list)
    default_effect: NetworkPolicyEffect = Field(
        NetworkPolicyEffect.ALLOW, alias="default_effect"
    )
    inserted_at: Optional[datetime] = Field(None, alias="inserted_at")
    updated_at: Optional[datetime] = Field(None, alias="updated_at")


class NetworkPolicySet(BaseModel):
    """Payload for ``PUT /computers/:id/network-policy``."""

    model_config = ConfigDict(populate_by_name=True)

    rules: List[NetworkPolicyRule]
    default_effect: Optional[NetworkPolicyEffect] = Field(
        None, alias="default_effect"
    )


# ---------------------------------------------------------------------------
# Events (real-time subscription)
# ---------------------------------------------------------------------------

class ComputerEvent(BaseModel):
    """A single typed event emitted by the in-VM event stream."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    type: str
    timestamp: Optional[datetime] = None
    payload: Dict[str, Any] = Field(default_factory=dict)
