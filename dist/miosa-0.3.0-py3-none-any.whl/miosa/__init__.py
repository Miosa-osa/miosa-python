"""MIOSA Python SDK — desktop infrastructure for AI agents.

Usage::

    from miosa import Miosa

    client = Miosa(api_key="msk_u_...")
    computer = client.computers.create(name="my-agent")
    computer.start()
    screenshot = computer.screenshot()
"""

from .client import AsyncMiosa, Miosa
from .errors import (
    AuthenticationError,
    ConnectionError,
    InsufficientCreditsError,
    MiosaError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .types import (
    AgentEvent,
    AgentSession,
    AgentSessionStatus,
    Computer as ComputerModel,
    ComputerEvent,
    ComputerSize,
    ComputerStatus,
    ComputerVisibility,
    CreditBalance,
    CreditTransaction,
    CreditUsage,
    CursorPosition,
    CustomDomainData,
    CustomDomainStatus,
    DirEntry,
    ExecResult,
    FileInfo,
    FileStat,
    NetworkPolicyData,
    NetworkPolicyEffect,
    NetworkPolicyProtocol,
    NetworkPolicyRule,
    ServiceData,
    ServiceLogEvent,
    ServiceStatus,
    SnapshotData,
    SnapshotProgressEvent,
    SnapshotStatus,
    WindowInfo,
    WorkspaceData,
)

__all__ = [
    # Clients
    "Miosa",
    "AsyncMiosa",
    # Errors
    "MiosaError",
    "AuthenticationError",
    "ConnectionError",
    "InsufficientCreditsError",
    "NotFoundError",
    "PermissionError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
    "ValidationError",
    # Types
    "AgentEvent",
    "AgentSession",
    "AgentSessionStatus",
    "ComputerEvent",
    "ComputerModel",
    "ComputerSize",
    "ComputerStatus",
    "ComputerVisibility",
    "CreditBalance",
    "CreditTransaction",
    "CreditUsage",
    "CursorPosition",
    "CustomDomainData",
    "CustomDomainStatus",
    "DirEntry",
    "ExecResult",
    "FileInfo",
    "FileStat",
    "NetworkPolicyData",
    "NetworkPolicyEffect",
    "NetworkPolicyProtocol",
    "NetworkPolicyRule",
    "ServiceData",
    "ServiceLogEvent",
    "ServiceStatus",
    "SnapshotData",
    "SnapshotProgressEvent",
    "SnapshotStatus",
    "WindowInfo",
    "WorkspaceData",
]

__version__ = "0.3.0"
