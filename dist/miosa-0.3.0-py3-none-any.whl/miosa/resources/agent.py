"""Agent (CUA session) resource — create, list, cancel, and stream AI agent sessions."""

from __future__ import annotations

import json as _json
from typing import TYPE_CHECKING, AsyncIterator, Iterator, List, Optional

from ..types import AgentEvent, AgentSession, AgentSessionCreate

if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class AgentResource:
    """Synchronous CUA session management."""

    def __init__(self, transport: SyncTransport, computer_id: str) -> None:
        self._transport = transport
        self._computer_id = computer_id

    def _path(self, *parts: str) -> str:
        base = f"/computers/{self._computer_id}/cua/sessions"
        if parts:
            return f"{base}/{'/'.join(parts)}"
        return base

    def run(
        self,
        goal: str,
        *,
        model_id: Optional[str] = None,
        max_turns: Optional[int] = None,
    ) -> AgentSession:
        """Create and start a new CUA agent session."""
        body = AgentSessionCreate(goal=goal, model_id=model_id, max_turns=max_turns)
        data = self._transport.request(
            "POST",
            self._path(),
            json_body=body.model_dump(exclude_none=True),
        )
        return AgentSession.model_validate(data)

    def list(self) -> List[AgentSession]:
        """List all CUA sessions for this computer."""
        data = self._transport.request("GET", self._path())
        if isinstance(data, dict) and "data" in data:
            return [AgentSession.model_validate(s) for s in data["data"]]
        if isinstance(data, list):
            return [AgentSession.model_validate(s) for s in data]
        return []

    def get(self, session_id: str) -> AgentSession:
        """Get a specific CUA session."""
        data = self._transport.request("GET", self._path(session_id))
        return AgentSession.model_validate(data)

    def cancel(self, session_id: str) -> AgentSession:
        """Cancel a running CUA session."""
        data = self._transport.request("DELETE", self._path(session_id))
        return AgentSession.model_validate(data)

    def stream(self, session_id: str) -> Iterator[AgentEvent]:
        """Stream SSE events from a CUA session.

        Yields ``AgentEvent`` objects. The stream ends when the server
        closes the connection or sends a terminal event.
        """
        for raw in self._transport.stream_sse(self._path(session_id, "events")):
            data = raw.get("data", "")
            try:
                parsed = _json.loads(data)
            except (ValueError, TypeError):
                parsed = data
            yield AgentEvent(
                type=raw.get("type", "message"),
                data=parsed,
                id=raw.get("id"),
            )


class AsyncAgentResource:
    """Asynchronous CUA session management."""

    def __init__(self, transport: AsyncTransport, computer_id: str) -> None:
        self._transport = transport
        self._computer_id = computer_id

    def _path(self, *parts: str) -> str:
        base = f"/computers/{self._computer_id}/cua/sessions"
        if parts:
            return f"{base}/{'/'.join(parts)}"
        return base

    async def run(
        self,
        goal: str,
        *,
        model_id: Optional[str] = None,
        max_turns: Optional[int] = None,
    ) -> AgentSession:
        body = AgentSessionCreate(goal=goal, model_id=model_id, max_turns=max_turns)
        data = await self._transport.request(
            "POST",
            self._path(),
            json_body=body.model_dump(exclude_none=True),
        )
        return AgentSession.model_validate(data)

    async def list(self) -> List[AgentSession]:
        data = await self._transport.request("GET", self._path())
        if isinstance(data, dict) and "data" in data:
            return [AgentSession.model_validate(s) for s in data["data"]]
        if isinstance(data, list):
            return [AgentSession.model_validate(s) for s in data]
        return []

    async def get(self, session_id: str) -> AgentSession:
        data = await self._transport.request("GET", self._path(session_id))
        return AgentSession.model_validate(data)

    async def cancel(self, session_id: str) -> AgentSession:
        data = await self._transport.request("DELETE", self._path(session_id))
        return AgentSession.model_validate(data)

    async def stream(self, session_id: str) -> AsyncIterator[AgentEvent]:
        """Stream SSE events from a CUA session asynchronously."""
        async for raw in self._transport.stream_sse(
            self._path(session_id, "events")
        ):
            data = raw.get("data", "")
            try:
                parsed = _json.loads(data)
            except (ValueError, TypeError):
                parsed = data
            yield AgentEvent(
                type=raw.get("type", "message"),
                data=parsed,
                id=raw.get("id"),
            )
