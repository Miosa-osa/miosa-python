# MIOSA Python SDK

Python SDK for the [MIOSA](https://miosa.ai) API — desktop infrastructure for AI agents.

Create and control cloud VMs that AI agents can operate: take screenshots, click, type, run commands, manage files, and orchestrate CUA (Computer Use Agent) sessions.

## Installation

```bash
pip install miosa
```

## Quick Start

```python
from miosa import Miosa

client = Miosa(api_key="msk_u_...")

# Create a fast code sandbox. `image` names a MIOSA-certified sandbox template.
sandbox = client.sandboxes.create(image="debian-12-sandbox-v8")
sandbox.run("python3 -c 'print(1 + 1)'")
sandbox.write_file("/workspace/app.py", "print('hello')")
print(sandbox.read_file("/workspace/app.py"))
sandbox.destroy()

# Create a computer
computer = client.computers.create(
    name="my-agent",
    template_type="miosa-desktop",
    size="small",
)
computer.start()
computer.wait(5)

# Desktop control
screenshot = computer.screenshot()  # PNG bytes
computer.click(100, 200)
computer.type("hello world")
computer.key("Enter")
computer.scroll("down", 3)

# Execute commands
result = computer.bash("ls -la")
print(result.output)

result = computer.python("print(2 + 2)")
print(result.output)

# File management
computer.files.upload("./local.txt", "/home/user/remote.txt")
files = computer.files.list("/home/user")
content = computer.files.download("/home/user/remote.txt")

# AI agent sessions
session = computer.agent.run(
    goal="Open Firefox and search for MIOSA",
    model_id="nemotron-3-super",
)

for event in computer.agent.stream(session.id):
    print(event.type, event.data)

# Cleanup
computer.stop()
computer.destroy()
```

## Async Usage

```python
from miosa import AsyncMiosa

async def main():
    async with AsyncMiosa(api_key="msk_u_...") as client:
        computer = await client.computers.create(name="my-agent")
        await computer.start()
        await computer.click(100, 200)
        screenshot = await computer.screenshot()

        session = await computer.agent.run(goal="Open a terminal")
        async for event in computer.agent.stream(session.id):
            print(event.type, event.data)

        await computer.destroy()
```

## Configuration

```python
client = Miosa(
    api_key="msk_u_...",       # or set MIOSA_API_KEY env var
    base_url="https://...",    # default: https://api.miosa.ai/api/v1
    timeout=60.0,              # request timeout in seconds
    max_retries=3,             # retries for 429/5xx with exponential backoff
)
```

## Desktop Control

| Method | Description |
|--------|-------------|
| `computer.screenshot()` | Capture PNG screenshot |
| `computer.click(x, y)` | Left-click at coordinates |
| `computer.click(x, y, button="right")` | Right-click |
| `computer.double_click(x, y)` | Double-click |
| `computer.type("text")` | Type text |
| `computer.key("Enter")` | Press a key |
| `computer.scroll("down", 3)` | Scroll direction + clicks |
| `computer.drag(x1, y1, x2, y2)` | Drag from point to point |
| `computer.wait(seconds)` | Wait on the desktop |
| `computer.cursor()` | Get cursor position |
| `computer.windows()` | List open windows |
| `computer.focus_window(id)` | Focus a window |
| `computer.launch("app")` | Launch an application |

## Error Handling

```python
from miosa import Miosa, AuthenticationError, NotFoundError, RateLimitError

try:
    computer = client.computers.get("nonexistent")
except NotFoundError:
    print("Computer not found")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited, retry after {e.retry_after}s")
```

### Exception Hierarchy

```
MiosaError
  AuthenticationError    (401)
  InsufficientCreditsError (402)
  PermissionError        (403)
  NotFoundError          (404)
  ValidationError        (422)
  RateLimitError         (429)
  ServerError            (5xx)
  ConnectionError
  TimeoutError
```

## Requirements

- Python 3.9+
- httpx
- pydantic v2

## License

MIT
