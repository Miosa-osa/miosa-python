"""Sandboxes — a thin helper over ``/computers`` that defaults ``template_type``
to ``"miosa-sandbox"`` (ephemeral code-exec rootfs, no desktop).

This mirrors the model used by E2B and Daytona: the computer is the single
resource type, and ``template_type`` selects its flavour. A "sandbox" is just
a computer with the lightweight template. Every other computer method (start,
stop, exec, files, agent, etc.) works identically.

Use :class:`Sandboxes` when you want code-exec ergonomics without typing out
``template_type="miosa-sandbox"`` on every call. Use :class:`ComputersResource`
directly when you want full control over the template.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport
    from .computer import AsyncComputer, Computer
    from .computers import AsyncComputersResource, ComputersResource


DEFAULT_TEMPLATE = "miosa-sandbox"


class Sandboxes:
    """Synchronous sandbox helper."""

    def __init__(self, computers: "ComputersResource") -> None:
        self._computers = computers

    def create(
        self,
        name: Optional[str] = None,
        *,
        image: Optional[str] = None,
        size: str = "small",
        template_type: str = DEFAULT_TEMPLATE,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "Computer":
        """Create a sandbox.

        ``image`` is an alias for ``template_type`` for Modal/HF-style call
        sites. Today it must name a MIOSA-certified sandbox template, not an
        arbitrary Docker image.

        The returned object is a full :class:`~miosa.resources.computer.Computer`.
        """
        if image is not None:
            if template_type != DEFAULT_TEMPLATE:
                raise TypeError("Pass either `image` or `template_type`, not both.")
            template_type = image

        if name is None:
            name = f"sandbox-{uuid.uuid4().hex[:12]}"

        return self._computers.create(
            name=name, template_type=template_type, size=size, metadata=metadata
        )

    def list(self) -> List["Computer"]:
        """List sandboxes (computers using the ``miosa-sandbox`` template)."""
        return [c for c in self._computers.list() if _is_sandbox(c)]

    def get(self, sandbox_id: str) -> "Computer":
        """Get a sandbox by ID. Alias for :meth:`ComputersResource.get`."""
        return self._computers.get(sandbox_id)

    def delete(self, sandbox_id: str) -> None:
        """Delete a sandbox. Alias for :meth:`ComputersResource.delete`."""
        self._computers.delete(sandbox_id)


class AsyncSandboxes:
    """Asynchronous sandbox helper — mirrors :class:`Sandboxes`."""

    def __init__(self, computers: "AsyncComputersResource") -> None:
        self._computers = computers

    async def create(
        self,
        name: Optional[str] = None,
        *,
        image: Optional[str] = None,
        size: str = "small",
        template_type: str = DEFAULT_TEMPLATE,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "AsyncComputer":
        if image is not None:
            if template_type != DEFAULT_TEMPLATE:
                raise TypeError("Pass either `image` or `template_type`, not both.")
            template_type = image

        if name is None:
            name = f"sandbox-{uuid.uuid4().hex[:12]}"

        return await self._computers.create(
            name=name, template_type=template_type, size=size, metadata=metadata
        )

    async def list(self) -> List["AsyncComputer"]:
        computers = await self._computers.list()
        return [c for c in computers if _is_sandbox(c)]

    async def get(self, sandbox_id: str) -> "AsyncComputer":
        return await self._computers.get(sandbox_id)

    async def delete(self, sandbox_id: str) -> None:
        await self._computers.delete(sandbox_id)


def _is_sandbox(computer: Any) -> bool:
    """Best-effort check — computers expose template_type on the underlying model.

    The bound `Computer` wrapper keeps the pydantic `ComputerModel` in
    `_data`. `data` is a `@property` that returns `_data`; both paths work.
    """
    # 1. Direct attribute (raw pydantic model)
    template = getattr(computer, "template_type", None)
    if template == DEFAULT_TEMPLATE:
        return True

    # 2. Wrapped Computer object — reach into `_data` or `data`
    for attr in ("_data", "data"):
        data = getattr(computer, attr, None)
        if data is None:
            continue
        # `data` may be a property returning the underlying model.
        candidate = data() if callable(data) else data
        if getattr(candidate, "template_type", None) == DEFAULT_TEMPLATE:
            return True

    return False
