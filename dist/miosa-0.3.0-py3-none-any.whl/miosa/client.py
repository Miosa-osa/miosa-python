"""Top-level Miosa and AsyncMiosa client classes."""

from __future__ import annotations

import os
from typing import Any, Optional

from ._http import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT, AsyncTransport, SyncTransport
from .resources.admin import Admin, AsyncAdmin
from .resources.computers import AsyncComputersResource, ComputersResource
from .resources.open_computers import AsyncOpenComputers, OpenComputers
from .resources.sandboxes import AsyncSandboxes, Sandboxes
from .resources.workspaces import AsyncWorkspaces, Workspaces
from .types import CreditBalance, CreditTransactionList, CreditUsage


class Miosa:
    """Synchronous MIOSA API client.

    Usage::

        from miosa import Miosa

        client = Miosa(api_key="msk_u_...")
        computer = client.computers.create(name="my-agent")
        computer.start()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        resolved_key = api_key or os.environ.get("MIOSA_API_KEY")
        if not resolved_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the MIOSA_API_KEY "
                "environment variable."
            )

        resolved_url = base_url or os.environ.get("MIOSA_BASE_URL", DEFAULT_BASE_URL)

        self._transport = SyncTransport(
            api_key=resolved_key,
            base_url=resolved_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.computers = ComputersResource(self._transport)
        self.sandboxes = Sandboxes(self.computers)
        self.workspaces = Workspaces(self._transport)
        self.admin = Admin(self._transport)
        self.open_computers = OpenComputers(self._transport)

    # -- credits / billing --

    def get_balance(self) -> CreditBalance:
        """Get the current credit balance."""
        data = self._transport.request("GET", "/credits/balance")
        return CreditBalance.model_validate(data)

    def get_transactions(self) -> CreditTransactionList:
        """Get credit transaction history."""
        data = self._transport.request("GET", "/credits/transactions")
        return CreditTransactionList.model_validate(data)

    def get_usage(self) -> CreditUsage:
        """Get current period credit usage."""
        data = self._transport.request("GET", "/credits/usage")
        return CreditUsage.model_validate(data)

    # -- lifecycle --

    def close(self) -> None:
        """Close the underlying HTTP transport."""
        self._transport.close()

    def __enter__(self) -> "Miosa":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Miosa(base_url={self._transport._base_url!r})"


class AsyncMiosa:
    """Asynchronous MIOSA API client.

    Usage::

        from miosa import AsyncMiosa

        async with AsyncMiosa(api_key="msk_u_...") as client:
            computer = await client.computers.create(name="my-agent")
            await computer.start()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        resolved_key = api_key or os.environ.get("MIOSA_API_KEY")
        if not resolved_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the MIOSA_API_KEY "
                "environment variable."
            )

        resolved_url = base_url or os.environ.get("MIOSA_BASE_URL", DEFAULT_BASE_URL)

        self._transport = AsyncTransport(
            api_key=resolved_key,
            base_url=resolved_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.computers = AsyncComputersResource(self._transport)
        self.sandboxes = AsyncSandboxes(self.computers)
        self.workspaces = AsyncWorkspaces(self._transport)
        self.admin = AsyncAdmin(self._transport)
        self.open_computers = AsyncOpenComputers(self._transport)

    async def get_balance(self) -> CreditBalance:
        data = await self._transport.request("GET", "/credits/balance")
        return CreditBalance.model_validate(data)

    async def get_transactions(self) -> CreditTransactionList:
        data = await self._transport.request("GET", "/credits/transactions")
        return CreditTransactionList.model_validate(data)

    async def get_usage(self) -> CreditUsage:
        data = await self._transport.request("GET", "/credits/usage")
        return CreditUsage.model_validate(data)

    async def close(self) -> None:
        await self._transport.close()

    async def __aenter__(self) -> "AsyncMiosa":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    def __repr__(self) -> str:
        return f"AsyncMiosa(base_url={self._transport._base_url!r})"
